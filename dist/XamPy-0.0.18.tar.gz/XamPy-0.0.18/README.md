# XamPy
Data Science Package






'''
python3 setup.py sdist bdist_wheel
python3 -m twine upload dist/*
'''



'''
things to add 

null handling
value search in cols
correlation charts
saving DF as a csv


'''

